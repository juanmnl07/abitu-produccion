<p><?php print $text; ?></p>
<div style="text-align: center;">
  <?php print $image; ?>
</div>
