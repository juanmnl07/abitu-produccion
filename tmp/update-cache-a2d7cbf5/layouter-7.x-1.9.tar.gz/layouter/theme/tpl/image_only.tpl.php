<div>
    <?php print $image; ?>
</div>
