<div style="text-align: center;">
  <?php print $image; ?>
</div>
<p><?php print $text; ?></p>
