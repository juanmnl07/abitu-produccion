<div style="text-align: center;"><?php print $image; ?></div>
<p style="-moz-column-count: 2; -moz-column-gap: 16px; -webkit-column-count: 2; -webkit-column-gap: 16px; column-count: 2; column-gap: 16px;"><?php print $text; ?></p>
