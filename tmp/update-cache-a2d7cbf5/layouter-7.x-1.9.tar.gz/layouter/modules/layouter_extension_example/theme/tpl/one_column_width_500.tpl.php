<p style="width: 500px;"><?php print $text; ?></p>
